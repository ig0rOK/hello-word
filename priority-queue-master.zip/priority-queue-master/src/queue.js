const MaxHeap = require('./max-heap.js');

class PriorityQueue {
	constructor(maxSize) {

	}

	push(data, priority) {

	}

	shift() {

	}

	size() {

	}

	isEmpty() {
		
	}
}

module.exports = PriorityQueue;
