class Node {
	constructor(data, priority) {

	}

	appendChild(node) {

	}

	removeChild(node) {

	}

	remove() {

	}

	swapWithParent() {
		
	}
}

module.exports = Node;
