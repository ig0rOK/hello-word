const MaxHeap = require('./src/max-heap');

const h = new MaxHeap();
window.h = h;
