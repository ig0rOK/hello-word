### Priority queue task

:warning: DO NOT FORK AND SUBMIT PRS TO THIS REPO :warning:

### Prerequisites
* Install [nodejs](https://nodejs.org/en/) (>= v6.2.0)
* open bash in this folder
* `npm install`

### Run tests
```sh
npm test
```

### Run in browser
```sh
npm start
```

open http://localhost:8080

---

© [R1ZZU](https://github.com/R1ZZU)
